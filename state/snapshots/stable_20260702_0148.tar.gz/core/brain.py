class Brain:
    def __init__(self, goals):
        self.goals = goals
        self.rules = []

    def add_rule(self, rule):
        self.rules.append(rule)

    def decide(self, event, memory):
        goals = self.goals.evaluate(event, memory)

        for g in goals:
            for r in self.rules:
                try:
                    out = r(event, memory, g)
                    if out:
                        return out
                except:
                    continue
        return None
