import json, os, time

class Memory:
    def __init__(self, path="state/memory.jsonl"):
        self.path = path
        self.cache = []
        os.makedirs("state", exist_ok=True)

        if os.path.exists(self.path):
            with open(self.path, "r") as f:
                for line in f:
                    if line.strip():
                        self.cache.append(json.loads(line))

    def write(self, key, value):
        record = {
            "key": key,
            "value": value,
            "ts": time.time()
        }

        self.cache.append(record)

        with open(self.path, "a") as f:
            f.write(json.dumps(record) + "\n")

    def last(self, n=5):
        return self.cache[-n:]

    def search(self, key):
        return [r for r in self.cache if r["key"] == key]
