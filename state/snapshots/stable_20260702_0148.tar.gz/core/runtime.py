import threading, time
from core.world import World
from core.agent import QAgent

class Runtime:
    def __init__(self):
        self.world = World()

        self.agent = QAgent(actions=[0, 1, 2])

        self.tick = 0
        self.running = False

    def start(self):
        self.running = True
        threading.Thread(target=self.loop, daemon=True).start()

    def loop(self):
        while self.running:
            self.tick += 1

            state_before = dict(self.world.state)

            action = self.agent.choose(state_before)
            self.world.step(action)

            reward = self.world.reward(state_before)

            self.agent.learn(
                state_before,
                action,
                reward,
                self.world.state
            )

            time.sleep(0.5)

    def status(self):
        return {
            "tick": self.tick,
            "world": self.world.state,
            "epsilon": self.agent.epsilon
        }

RUNTIME = Runtime()
