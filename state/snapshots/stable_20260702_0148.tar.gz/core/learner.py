class Learner:
    def __init__(self):
        self.score = {}

    def update(self, rule, reward):
        key = str(rule)

        if key not in self.score:
            self.score[key] = 0

        self.score[key] += reward

    def quality(self, rule):
        return self.score.get(str(rule), 0)
