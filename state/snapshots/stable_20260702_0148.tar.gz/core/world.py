import random

class World:
    def __init__(self):
        self.state = {"energy": 100, "stability": 100}

    def step(self, action):
        # actions:
        # 0 = do_nothing
        # 1 = boost_energy
        # 2 = boost_stability

        if action == 0:
            self.state["stability"] -= 0.2

        elif action == 1:
            self.state["energy"] += 0.5
            self.state["stability"] -= 0.1

        elif action == 2:
            self.state["stability"] += 0.5
            self.state["energy"] -= 0.2

        # natural decay
        self.state["energy"] -= 0.3

        return self.state

    def reward(self, before):
        after = self.state
        return (
            (after["stability"] - before["stability"]) +
            (after["energy"] - before["energy"])
        )
