import json, os, time

class SelfModify:
    def __init__(self, runtime):
        self.runtime = runtime
        os.makedirs("state", exist_ok=True)

    def commit_rule(self, rule):
        with open("state/generated_rules.jsonl", "a") as f:
            f.write(json.dumps(rule) + "\n")

        self.runtime.kernel.emit("self_modify", rule)
