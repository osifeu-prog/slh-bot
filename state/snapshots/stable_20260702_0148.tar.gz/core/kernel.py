import time
from threading import RLock

class Kernel:
    def __init__(self):
        self.events = []
        self.lock = RLock()

    def emit(self, event, data=None):
        with self.lock:
            self.events.append({
                "event": event,
                "data": data,
                "ts": time.time()
            })
