class AgentEngine:
    def __init__(self, runtime):
        self.runtime = runtime
        self.agents = []

    def register(self, agent):
        self.agents.append(agent)

    def handle(self, event):
        for agent in self.agents:
            try:
                if agent.match(event):
                    result = agent.act(event, self.runtime)

                    if result:
                        self.runtime.bus.emit("agent:action", result)

            except Exception as e:
                self.runtime.bus.emit("agent:error", {
                    "agent": agent.__class__.__name__,
                    "error": str(e)
                })
