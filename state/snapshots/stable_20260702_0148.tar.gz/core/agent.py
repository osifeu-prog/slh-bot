import random

class QAgent:
    def __init__(self, actions):
        self.q = {}  # state -> action values
        self.actions = actions
        self.epsilon = 0.2
        self.lr = 0.1
        self.gamma = 0.9

    def _key(self, state):
        # discretize state
        return (
            round(state["energy"], 0),
            round(state["stability"], 0)
        )

    def choose(self, state):
        key = self._key(state)

        if random.random() < self.epsilon or key not in self.q:
            return random.choice(self.actions)

        return max(self.q[key], key=self.q[key].get)

    def learn(self, state, action, reward, next_state):
        key = self._key(state)
        next_key = self._key(next_state)

        if key not in self.q:
            self.q[key] = {a: 0 for a in self.actions}
        if next_key not in self.q:
            self.q[next_key] = {a: 0 for a in self.actions}

        best_next = max(self.q[next_key].values())

        old = self.q[key][action]
        self.q[key][action] = old + self.lr * (
            reward + self.gamma * best_next - old
        )
