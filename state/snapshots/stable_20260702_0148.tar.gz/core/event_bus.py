class EventBus:
    def __init__(self, workers=1):
        self.handlers = {}
        self.workers = workers

    def register(self, event, handler):
        self.handlers.setdefault(event, []).append(handler)

    def on(self, event, handler):
        self.register(event, handler)

    def emit(self, event, data=None):
        for handler in self.handlers.get(event, []):
            try:
                handler(data)
            except Exception as e:
                print(f"[EventBus error] {event}: {e}")
