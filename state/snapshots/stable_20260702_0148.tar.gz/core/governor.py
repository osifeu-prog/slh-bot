class Governor:
    def __init__(self):
        self.scores = {}
        self.max_rules = 50

    def score_rule(self, rule, success=True):
        key = str(rule)

        if key not in self.scores:
            self.scores[key] = 0

        self.scores[key] += 1 if success else -1

    def should_accept(self, rule, current_rules):
        # limit explosion
        if len(current_rules) > self.max_rules:
            return False

        key = str(rule)
        score = self.scores.get(key, 0)

        # accept only meaningful rules
        return score >= 2
