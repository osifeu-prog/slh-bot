class Guard:
    def allow(self, rules, rule):
        if len(rules) > 100:
            return False
        if not rule or "behavior" not in rule:
            return False
        return True
