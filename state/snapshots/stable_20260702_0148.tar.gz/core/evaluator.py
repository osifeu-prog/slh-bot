class Evaluator:
    def score(self, event, decision):
        # simple but real signal separation
        if event["event"] == "tick":
            return 0.1  # low value

        if decision:
            return 1.0

        return -0.2
