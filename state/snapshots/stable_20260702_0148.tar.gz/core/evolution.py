class Evolution:
    def __init__(self):
        self.history = []

    def record(self, event, decision, reward):
        self.history.append((event, decision, reward))

    def propose(self):
        if len(self.history) < 3:
            return None

        e, d, r = self.history[-1]

        if not d:
            return None

        return {
            "event": e["event"],
            "behavior": d,
            "confidence": r
        }
