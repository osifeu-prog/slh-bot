from core.brain import Brain
from core.goals import Goals

class Orchestrator:
    def __init__(self, runtime):
        self.runtime = runtime
        self.goals = Goals()
        self.brain = Brain(self.goals)

    def handle(self, event):
        decision = self.brain.decide(event, self.runtime.memory)

        if decision:
            self.runtime.memory.write("decision", decision)
            self.runtime.kernel.emit("action", decision)

        return decision
