# DISABLED DUPLICATE BUS (using event_bus only)
class EventBus: pass
