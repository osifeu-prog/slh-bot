class Goals:
    def __init__(self):
        self.goals = []

    def add(self, name, priority=1, condition=None):
        self.goals.append({
            "name": name,
            "priority": priority,
            "condition": condition
        })

    def evaluate(self, event, memory):
        active = []

        for g in self.goals:
            try:
                if g["condition"] is None or g["condition"](event, memory):
                    active.append(g)
            except:
                pass

        return sorted(active, key=lambda x: x["priority"], reverse=True)
