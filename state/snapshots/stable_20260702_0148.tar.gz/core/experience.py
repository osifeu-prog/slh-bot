class Experience:
    def __init__(self):
        self.records = []

    def add(self, event, decision, outcome_score=1.0):
        self.records.append({
            "event": event,
            "decision": decision,
            "score": outcome_score
        })

    def success_rate(self):
        if not self.records:
            return 0

        return sum(r["score"] for r in self.records) / len(self.records)
