class WorldPatch:
    def normalize_reward(self, r):
        if r > 5:
            return 1
        if r < -5:
            return -1
        return r / 5
