class RuleStore:
    def __init__(self):
        self.rules = []

    def add(self, rule):
        if rule not in self.rules:
            self.rules.append(rule)

    def size(self):
        return len(self.rules)
